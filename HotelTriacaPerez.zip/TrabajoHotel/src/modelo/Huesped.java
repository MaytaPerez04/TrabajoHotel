package modelo;

public class Huesped {

}
