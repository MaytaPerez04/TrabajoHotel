package Administrador.usuarios;

import javax.swing.*;
import java.awt.*;
import modelo.Administrador;

public class EditarUsuariosFrame extends JFrame {

    public EditarUsuariosFrame() {
        setTitle("Editar Usuario");
        setSize(450, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 245, 245));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // --- HEADER ---
        JPanel header = new JPanel();
        header.setBackground(new Color(192, 57, 43));
        header.setPreferredSize(new Dimension(450, 60));
        JLabel titulo = new JLabel("Editar Usuario");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.add(titulo);
        add(header, BorderLayout.NORTH);

        // --- FORM PANEL ---
        JPanel form = new JPanel();
        form.setBackground(new Color(245, 245, 245));
        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        form.setLayout(new GridLayout(10, 1, 10, 10));

        JTextField tfId = new JTextField();
        JTextField tfNombre = new JTextField();
        JTextField tfUsuario = new JTextField();
        JPasswordField tfPass = new JPasswordField();
        String[] roles = {"Administrador", "Recepcion", "Limpieza"};
        JComboBox<String> cbRol = new JComboBox<>(roles);

        Dimension campoGrande = new Dimension(0, 35);
        tfId.setPreferredSize(campoGrande);
        tfNombre.setPreferredSize(campoGrande);
        tfUsuario.setPreferredSize(campoGrande);
        tfPass.setPreferredSize(campoGrande);
        cbRol.setPreferredSize(campoGrande);

        form.add(crearEtiqueta("ID del Usuario:"));
        form.add(tfId);
        form.add(crearEtiqueta("Nombre:"));
        form.add(tfNombre);
        form.add(crearEtiqueta("Usuario:"));
        form.add(tfUsuario);
        form.add(crearEtiqueta("Contraseña:"));
        form.add(tfPass);
        form.add(crearEtiqueta("Rol:"));
        form.add(cbRol);

        add(form, BorderLayout.CENTER);

        // --- BOTONES ---
        JPanel botones = new JPanel();
        botones.setBackground(new Color(245, 245, 245));
        botones.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton btnEditar = new JButton("Editar");
        JButton btnCancelar = new JButton("Cancelar");

        estiloBotonRojo(btnEditar, new Color(192, 57, 43));
        estiloBotonRojo(btnCancelar, new Color(231, 76, 60));

        btnEditar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(tfId.getText().trim());
                String nombre = tfNombre.getText().trim();
                String usuario = tfUsuario.getText().trim();
                String pass = new String(tfPass.getPassword()).trim();
                String rol = (String) cbRol.getSelectedItem();

                Administrador.editarUsuario(id, nombre, usuario, pass, rol);
                JOptionPane.showMessageDialog(this, "Usuario editado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID inválido.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancelar.addActionListener(e -> dispose());

        botones.add(btnEditar);
        botones.add(btnCancelar);
        add(botones, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JLabel crearEtiqueta(String texto) {
        JLabel label = new JLabel(texto);
        label.setFont(new Font("Segoe UI", Font.BOLD, 14));
        return label;
    }

    private void estiloBotonRojo(JButton btn, Color colorFondo) {
        btn.setBackground(colorFondo);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
