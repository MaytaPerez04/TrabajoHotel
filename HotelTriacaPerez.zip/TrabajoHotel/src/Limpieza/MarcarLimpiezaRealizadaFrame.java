package Limpieza;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import controlador.ConexionBD;

public class MarcarLimpiezaRealizadaFrame extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;
    private JLabel lblEstado;

    public MarcarLimpiezaRealizadaFrame() {

        setTitle("Marcar habitaciones como 'en limpieza'");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(255, 224, 130));

        // ----- TÍTULO -----
        JLabel lblTitulo = new JLabel("Habitaciones para comenzar limpieza", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(80, 80, 80));
        add(lblTitulo, BorderLayout.NORTH);

        // ----- TABLA -----
        String[] columnas = { "ID", "Tipo", "Estado", "Limpieza" };
        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setRowHeight(24);

        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // ----- PIE (ESTADO + BOTONES) -----
        lblEstado = new JLabel("Seleccione una habitación para marcarla como 'en limpieza'.");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEstado.setForeground(new Color(60, 60, 60));

        JButton btnCambiar = new JButton("Marcar como 'en limpieza'");
        btnCambiar.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JPanel panelBotones = new JPanel();
        panelBotones.setOpaque(false);
        panelBotones.add(btnCambiar);
        panelBotones.add(btnCerrar);

        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setBackground(new Color(255, 224, 130));
        panelSur.add(lblEstado, BorderLayout.CENTER);
        panelSur.add(panelBotones, BorderLayout.EAST);

        add(panelSur, BorderLayout.SOUTH);

        // Acciones
        btnCambiar.addActionListener(e -> marcarComoEnLimpieza());
        btnCerrar.addActionListener(e -> dispose());

        // Cargar datos
        cargarHabitaciones();

        setVisible(true);
    }

    private void cargarHabitaciones() {
        modelo.setRowCount(0);
        lblEstado.setText("Cargando habitaciones...");

        try (Connection conn = ConexionBD.conectar()) {

            String sql = "SELECT idHabitacion, tipo, estado, estadoLimpieza "
                       + "FROM habitacion "
                       + "WHERE estadoLimpieza = 'limpiar' "
                       + "ORDER BY tipo, idHabitacion";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            int count = 0;
            while (rs.next()) {
                count++;
                modelo.addRow(new Object[]{
                        rs.getInt("idHabitacion"),
                        rs.getString("tipo"),
                        rs.getString("estado"),
                        rs.getString("estadoLimpieza")
                });
            }

            if (count == 0) {
                lblEstado.setText("No hay habitaciones en estado 'limpiar'.");
            } else {
                lblEstado.setText("Total de habitaciones en 'limpiar': " + count);
            }

        } catch (SQLException e) {
            lblEstado.setText("No se pudieron cargar las habitaciones. Revisá la conexión.");
        }
    }

    private void marcarComoEnLimpieza() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            lblEstado.setText("Primero seleccioná una habitación en la tabla.");
            return;
        }

        int idHabitacion = (int) modelo.getValueAt(fila, 0);

        try (Connection conn = ConexionBD.conectar()) {

            String sql = "UPDATE habitacion "
                       + "SET estadoLimpieza = 'limpiando' "
                       + "WHERE idHabitacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idHabitacion);
            ps.executeUpdate();

            lblEstado.setText("Habitación #" + idHabitacion + " actualizada a 'limpiando'.");
            cargarHabitaciones();

        } catch (SQLException e) {
            lblEstado.setText("No se pudo actualizar la habitación. Intentá de nuevo.");
        }
    }
}
