package Limpieza;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import controlador.ConexionBD;

public class VerHabitacionesFrame extends JFrame {

    public VerHabitacionesFrame() {

        setTitle("Habitaciones pendientes de limpieza");
        setSize(650, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(255, 224, 130));

        // Título
        JLabel lblTitulo = new JLabel("Habitaciones pendientes de limpieza", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(80, 80, 80));
        add(lblTitulo, BorderLayout.NORTH);

        // Tabla
        String[] columnas = { "ID", "Tipo", "Estado", "Estado limpieza" };
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setRowHeight(24);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // Pie
        JLabel lblEstado = new JLabel("Cargando habitaciones pendientes...", SwingConstants.CENTER);
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEstado.setForeground(new Color(60, 60, 60));

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setBackground(new Color(255, 224, 130));
        panelSur.add(lblEstado, BorderLayout.CENTER);

        JPanel panelBoton = new JPanel();
        panelBoton.setOpaque(false);
        panelBoton.add(btnCerrar);
        panelSur.add(panelBoton, BorderLayout.EAST);

        add(panelSur, BorderLayout.SOUTH);

        btnCerrar.addActionListener(e -> dispose());

        // Cargar datos
        try (Connection conn = ConexionBD.conectar()) {

            String sql = "SELECT idHabitacion, tipo, estado, estadoLimpieza "
                       + "FROM habitacion "
                       + "WHERE estadoLimpieza IN ('limpiar', 'limpiando') "
                       + "ORDER BY tipo, idHabitacion";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            int count = 0;
            while (rs.next()) {
                count++;
                modelo.addRow(new Object[]{
                        rs.getInt("idHabitacion"),
                        rs.getString("tipo"),
                        rs.getString("estado"),
                        rs.getString("estadoLimpieza")
                });
            }

            if (count == 0) {
                lblEstado.setText("No hay habitaciones pendientes de limpieza.");
            } else {
                lblEstado.setText("Total de habitaciones pendientes: " + count);
            }

        } catch (SQLException e) {
            lblEstado.setText("No se pudieron cargar las habitaciones. Revisá la conexión.");
        }

        setVisible(true);
    }
}
