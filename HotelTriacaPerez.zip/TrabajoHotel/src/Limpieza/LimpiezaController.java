package Limpieza;

// Controlador simple que solo abre la ventana principal de limpieza.
// No usa cuadros de diálogo emergentes, todo se maneja con JFrames.
public class LimpiezaController {

    public static void mostrarMenuLimpieza() {
        new LimpiezaFrame();
    }
}
