package Limpieza;

import javax.swing.*;
import java.awt.*;

public class LimpiezaFrame extends JFrame {

    public LimpiezaFrame() {
        setTitle("Panel de Limpieza");
        setSize(600, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // ----- HEADER -----
        JPanel header = new JPanel();
        header.setBackground(new Color(52, 152, 219));
        header.setPreferredSize(new Dimension(600, 80));

        JLabel titulo = new JLabel("Panel de Limpieza");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titulo.setForeground(Color.WHITE);
        header.add(titulo);

        add(header, BorderLayout.NORTH);

        // ----- BOTONES -----
        JPanel center = new JPanel();
        center.setBackground(new Color(236, 240, 241));
        center.setLayout(new GridLayout(4, 1, 15, 15));
        center.setBorder(BorderFactory.createEmptyBorder(25, 80, 25, 80));

        JButton btnVerPendientes = crearBoton("Ver habitaciones pendientes");
        JButton btnMarcarEnLimpieza = crearBoton("Marcar como 'en limpieza'");
        JButton btnMarcarLimpia = crearBoton("Marcar como 'limpia'");
        JButton btnCerrar = crearBoton("Cerrar");

        center.add(btnVerPendientes);
        center.add(btnMarcarEnLimpieza);
        center.add(btnMarcarLimpia);
        center.add(btnCerrar);

        add(center, BorderLayout.CENTER);

        // ----- ACCIONES (TODO JFRAME) -----

        // Ver todas las habitaciones en 'limpiar' o 'limpiando'
        btnVerPendientes.addActionListener(e -> mostrarPedidosLimpieza());

        // Pasar de 'limpiar' -> 'limpiando'
        btnMarcarEnLimpieza.addActionListener(e -> new MarcarLimpiezaRealizadaFrame());

        // Pasar de 'limpiando' -> 'limpia'
        btnMarcarLimpia.addActionListener(e -> new MarcarLimpiezaFrame());

        btnCerrar.addActionListener(e -> dispose());

        setVisible(true);
    }

    private JButton crearBoton(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(Color.WHITE);
        btn.setForeground(new Color(52, 73, 94));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(52, 152, 219), 2));
        return btn;
    }

    // ⬇⬇⬇ IMPORTANTE: YA NO HAY JOptionPane ACÁ ⬇⬇⬇
    public void mostrarPedidosLimpieza() {
        // Si cualquier otra parte del código llama a este método,
        // en vez de mostrar un dialog, abrimos el JFrame con la tabla.
        new VerHabitacionesFrame();
    }
}
