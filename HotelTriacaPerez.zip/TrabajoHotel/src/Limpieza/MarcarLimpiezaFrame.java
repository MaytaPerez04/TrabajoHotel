package Limpieza;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import controlador.ConexionBD;

public class MarcarLimpiezaFrame extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;
    private JLabel lblEstado;

    public MarcarLimpiezaFrame() {

        setTitle("Marcar habitaciones como 'limpias'");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(255, 224, 130));

        // Título
        JLabel lblTitulo = new JLabel("Habitaciones en limpieza (limpiando)", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitulo.setForeground(new Color(80, 80, 80));
        add(lblTitulo, BorderLayout.NORTH);

        // Tabla
        String[] columnas = { "ID", "Tipo", "Estado", "Limpieza" };
        modelo = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setRowHeight(24);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // Pie
        lblEstado = new JLabel("Seleccione una habitación y pulse \"Marcar como limpia\".");
        lblEstado.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEstado.setForeground(new Color(60, 60, 60));

        JButton btnMarcar = new JButton("Marcar como limpia");
        btnMarcar.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JPanel panelBotones = new JPanel();
        panelBotones.setOpaque(false);
        panelBotones.add(btnMarcar);
        panelBotones.add(btnCerrar);

        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setBackground(new Color(255, 224, 130));
        panelSur.add(lblEstado, BorderLayout.CENTER);
        panelSur.add(panelBotones, BorderLayout.EAST);

        add(panelSur, BorderLayout.SOUTH);

        // Acciones
        btnMarcar.addActionListener(e -> marcarComoLimpia());
        btnCerrar.addActionListener(e -> dispose());

        // Datos
        cargarHabitaciones();

        setVisible(true);
    }

    private void cargarHabitaciones() {
        modelo.setRowCount(0);
        lblEstado.setText("Cargando habitaciones...");

        try (Connection conn = ConexionBD.conectar()) {

            String sql = "SELECT idHabitacion, tipo, estado, estadoLimpieza "
                       + "FROM habitacion "
                       + "WHERE estadoLimpieza = 'limpiando' "
                       + "ORDER BY tipo, idHabitacion";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            int count = 0;
            while (rs.next()) {
                count++;
                modelo.addRow(new Object[]{
                        rs.getInt("idHabitacion"),
                        rs.getString("tipo"),
                        rs.getString("estado"),
                        rs.getString("estadoLimpieza")
                });
            }

            if (count == 0) {
                lblEstado.setText("No hay habitaciones en estado 'limpiando'.");
            } else {
                lblEstado.setText("Total de habitaciones en limpieza: " + count);
            }

        } catch (SQLException e) {
            lblEstado.setText("No se pudieron cargar las habitaciones. Revisá la conexión.");
        }
    }

    private void marcarComoLimpia() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            lblEstado.setText("Primero seleccioná una habitación en la tabla.");
            return;
        }

        int idHabitacion = (int) modelo.getValueAt(fila, 0);

        try (Connection conn = ConexionBD.conectar()) {

            String sql = "UPDATE habitacion SET estadoLimpieza = 'limpia' WHERE idHabitacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idHabitacion);
            ps.executeUpdate();

            lblEstado.setText("Habitación #" + idHabitacion + " actualizada a 'limpia'.");
            cargarHabitaciones();

        } catch (SQLException e) {
            lblEstado.setText("No se pudo actualizar la habitación. Intentá de nuevo.");
        }
    }
}
